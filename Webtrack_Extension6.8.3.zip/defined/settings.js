var settings = {
  companie: {
    name: "WebTrack"
  },
  id: 'de.unild.webtrack',
  lang: 'de',
  versionType: 'Chrome',
  mobile: false,
  requireVersion: {
    chrome: 45
  },
  server: "https://webtrack.uni-landau.de:8443/"
  // server: "https://va.uni-landau.de:8443/"
}
