var settings = {
  companie: {
    name: "WebTrack"
  },
  id: 'localhost',
  lang: 'de',
  versionType: 'Chrome',
  mobile: false,
  requireVersion: {
    chrome: 45
  },
  server: "https://localhost:8443/"
}
