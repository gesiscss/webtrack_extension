var settings = {
  companie: {
    name: "WebTrack"
  },
  lang: 'de',
  versionType: 'Chrome',
  mobile: false,
  server: "https://webtrack.uni-landau.de:8443/"
  // server: "https://va.uni-landau.de:8443/"
}
